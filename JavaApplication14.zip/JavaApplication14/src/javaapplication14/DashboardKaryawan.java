package javaapplication14;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DashboardKaryawan extends javax.swing.JFrame {

    public DashboardKaryawan() {
        initComponents();
    }

    public void tampilkanDataKeTabel() {
    DefaultTableModel model = new DefaultTableModel(new String[]{"ID Menu", "Kategori Menu", "Jenis Menu", "Nama Menu", "Harga Menu"}, 0);

    String sql = "SELECT * FROM menu";
    
    try (Connection conn = this.connect(); 
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        
        while (rs.next()) {
            String id = rs.getString("id_menu");
            String kategori = rs.getString("kategori_menu");
            String jenis = rs.getString("jenis_menu");
            String nama = rs.getString("nama_menu");
            String harga = rs.getString("harga_menu");
            model.addRow(new Object[]{id, kategori, jenis, nama, harga});
        }
        
        jTableMenu.setModel(model);
        
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableMenu = new javax.swing.JTable();
        btnTambahMenu = new javax.swing.JButton();
        btnHapusMenu = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtIDmenu = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtNamamenu = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jComboBoxKategoriMenu = new javax.swing.JComboBox();
        jComboBoxJenisMenu = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        txtHargaMenu = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtidKaryawan = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Dashboard Karyawan");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Manajemen Menu");

        jTableMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Menu", "Kategori Menu", "Nama Menu", "Jenis Menu", "Harga Menu"
            }
        ));
        jScrollPane1.setViewportView(jTableMenu);

        btnTambahMenu.setText("Tambah");
        btnTambahMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahMenuActionPerformed(evt);
            }
        });

        btnHapusMenu.setText("Hapus");
        btnHapusMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusMenuActionPerformed(evt);
            }
        });

        jLabel4.setText("ID Menu");

        txtIDmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIDmenuActionPerformed(evt);
            }
        });

        jLabel5.setText("Kategori");

        jLabel6.setText("Nama Menu");

        txtNamamenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamamenuActionPerformed(evt);
            }
        });

        jLabel7.setText("Jenis");

        jComboBoxKategoriMenu.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Utama", "Ringan", "Penutup" }));
        jComboBoxKategoriMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxKategoriMenuActionPerformed(evt);
            }
        });

        jComboBoxJenisMenu.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cepat Saji", "Sehat" }));
        jComboBoxJenisMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxJenisMenuActionPerformed(evt);
            }
        });

        jLabel8.setText("Harga");

        txtHargaMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHargaMenuActionPerformed(evt);
            }
        });

        jLabel9.setText("ID Karyawan");

        txtidKaryawan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidKaryawanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnTambahMenu)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnHapusMenu))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtIDmenu)
                            .addComponent(txtNamamenu, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                            .addComponent(jComboBoxKategoriMenu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBoxJenisMenu, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtHargaMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
                            .addComponent(txtidKaryawan, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE))))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtIDmenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBoxKategoriMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtNamamenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jComboBoxJenisMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtHargaMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtidKaryawan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambahMenu)
                    .addComponent(btnHapusMenu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxJenisMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxJenisMenuActionPerformed
        
    }//GEN-LAST:event_jComboBoxJenisMenuActionPerformed

    private void txtNamamenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamamenuActionPerformed
        
    }//GEN-LAST:event_txtNamamenuActionPerformed

    private void jComboBoxKategoriMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxKategoriMenuActionPerformed
        
    }//GEN-LAST:event_jComboBoxKategoriMenuActionPerformed

    private void txtIDmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIDmenuActionPerformed
        
    }//GEN-LAST:event_txtIDmenuActionPerformed

    private void btnTambahMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahMenuActionPerformed
        String idMenu = txtIDmenu.getText();
    String kategoriMenu = jComboBoxKategoriMenu.getSelectedItem().toString();
    String jenisMenu = jComboBoxJenisMenu.getSelectedItem().toString();
   String namaMenu = txtNamamenu.getText();
    String hargaMenu = txtHargaMenu.getText();
    String idKaryawan= txtidKaryawan.getText();
    Connection conn = null;
    PreparedStatement pst = null;

    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testes", "root", "");
        String sql = "INSERT INTO menu (id_menu, kategori_menu, nama_menu, jenis_menu, harga_menu, karyawan_id_karyawan) VALUES (?, ?, ?, ?, ?, ?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1, idMenu);
        pst.setString(2, kategoriMenu);
         pst.setString(3, namaMenu);
         pst.setString(4, jenisMenu);
         pst.setString(5, hargaMenu);
 pst.setString(6, idKaryawan);
        int i = pst.executeUpdate();
        if (i > 0) {
            JOptionPane.showMessageDialog(null, "Menu berhasil ditambahkan");
        } else {
            JOptionPane.showMessageDialog(null, "Menu tidak berhasil ditambahkan");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e);
    } finally {
        try {
            if (pst != null) { pst.close(); }
            if (conn != null) { conn.close(); }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
    }//GEN-LAST:event_btnTambahMenuActionPerformed

    private void btnHapusMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusMenuActionPerformed
        
    }//GEN-LAST:event_btnHapusMenuActionPerformed

    private void txtHargaMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHargaMenuActionPerformed
      
    }//GEN-LAST:event_txtHargaMenuActionPerformed

    private void txtidKaryawanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidKaryawanActionPerformed
        
    }//GEN-LAST:event_txtidKaryawanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardKaryawan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashboardKaryawan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHapusMenu;
    private javax.swing.JButton btnTambahMenu;
    private javax.swing.JComboBox jComboBoxJenisMenu;
    private javax.swing.JComboBox jComboBoxKategoriMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableMenu;
    private javax.swing.JTextField txtHargaMenu;
    private javax.swing.JTextField txtIDmenu;
    private javax.swing.JTextField txtNamamenu;
    private javax.swing.JTextField txtidKaryawan;
    // End of variables declaration//GEN-END:variables

    private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/testes"; 
    String user = "root"; 
    String password = "";

    Connection conn = null;
    try {
        // Mencoba koneksi ke database
        conn = DriverManager.getConnection(url, user, password);
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    return conn;
    }
}
